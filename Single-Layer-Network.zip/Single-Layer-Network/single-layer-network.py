import numpy as np
import csv

def load_data(filename):
    data = []
    with open(filename, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            language = row[0]
            text = row[1].lower()
            count = count_letters(text)
            normalized_count = normalize(count)
            data.append((language, normalized_count))
    return data


def train_network(training_data):
    languages = set(entry[0] for entry in training_data)
    num_languages = len(languages)
    input_size = len(training_data[0][1])
    weights = np.random.rand(num_languages, input_size)

    for _ in range(100):
        for language, input_vector in training_data:
            language_index = list(languages).index(language)
            predicted_language = np.argmax(np.dot(weights, input_vector))
            if language_index != predicted_language:
                weights[language_index] += input_vector
                weights[predicted_language] -= input_vector

    return weights

def normalize(vector):
    norm = np.linalg.norm(vector)
    if norm == 0:
        return vector
    return vector / norm



def count_letters(text):
    count = [0] * 26
    for char in text:
        if char.isalpha():
            index = ord(char.lower()) - ord('a')
            count[index] += 1
    return count




def classify_text(text, weights, languages):
    count = count_letters(text)
    normalized_count = normalize(count)
    output = np.dot(weights, normalized_count)
    language_index = np.argmax(output)
    return languages[language_index]


def testAccuracy(test_data, weights, languages):
    correct = 0
    total = len(test_data)
    for language, text in test_data:
        predicted_language = classify_text(text, weights, languages)
        if predicted_language == language:
            correct += 1
    accuracy = correct / total
    return accuracy

#Console

training_data = load_data('lang.train.csv')
test_data = load_data('lang.test.csv')


languages = set(entry[0] for entry in training_data)
weights = train_network(training_data)


accuracy = testAccuracy(test_data, weights, languages)
print("Test Accuracy:", accuracy)

while True:
    text = input("Enter a text to classify (or 'exit' to quit): ")
    if text.lower() == 'exit':
        break
    language = classify_text(text, weights, languages)
    print("Predicted Language:", language)
