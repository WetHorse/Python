import numpy as np


def loadData(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()
    X = []
    y = []
    for line in lines:
        data = line.strip().split(',')
        X.append(list(map(float, data[:-1])))
        y.append(1 if data[-1] == 'Iris-virginica' else 0)
    return np.array(X), np.array(y)

def accuracyCalculating(y_true, y_pred):
    correct = sum(1 for true, pred in zip(y_true, y_pred) if true == pred)
    accuracy = correct / len(y_true) * 100
    return accuracy
#3 fix this
def perceptronPredict(X_test, weights, bias):
    predictions = []
    for i in range(len(X_test)):
        activation = np.dot(weights, X_test[i]) + bias
        prediction = 1 if activation >= 0 else 0
        predictions.append(prediction)
    return predictions
#4 wrong output. dft to fix


def perceptronTraining(X_train, y_train, learning_rate=0.01, n_iterations=1000):

    num_features = X_train.shape[1]
    weigts = np.random.rand(num_features)
    bias = np.random.rand(1)

    for _ in range(n_iterations):
        for i in range(X_train.shape[0]):
            activation = np.dot(weigts, X_train[i]) + bias
            y_pred = 1 if activation >= 0 else 0
            error = y_train[i] - y_pred
            weigts += learning_rate * error * X_train[i]
            bias += learning_rate * error

    return weigts, bias



#  -----Console---

Xt, Yt = loadData("perceptron.data") #tested


learning_rate = float(input("Enter the rate "))
n_iterations = int(input("Enter the number of iterations: "))
weights, bias = perceptronTraining(Xt, Yt, learning_rate, n_iterations)


X_test, y_test = loadData("perceptron.test.data")


y_pred = perceptronPredict(X_test, weights, bias)
accuracy = accuracyCalculating(y_test, y_pred)
print("Test Accuracy:", accuracy)

while True:
    user_input = input("Enter values like (4.6, 3.5, 3.9) or press 'q' to quit: ")
    if user_input.lower() == "q":
        break
    try:
        user_input = np.array([float(x) for x in user_input.split(',')])
        prediction = perceptronPredict([user_input], weights, bias)[0]
        if prediction == 0:
            print("Predicted class: Iris-versicolor")
        else:
            print("Predicted class: Iris-virginica")
    except ValueError:
        print("Invalid input.")
