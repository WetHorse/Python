import os
import zipfile
import hashlib
import requests
import time
import re
from io import BytesIO
import tkinter as tk
from tkinterdnd2 import DND_FILES, TkinterDnD
from PIL import Image, ImageTk
import customtkinter


class Functional:
    def read_passwords(self, password_file):
        with open(password_file, 'r') as f:
            passwords = f.read().splitlines()
        return passwords

    def retrieve_password(self, zip_file, passwords):
        start_time = time.time()
        with zipfile.ZipFile(zip_file) as zf:
            for password in passwords:
                try:
                    zf.extractall(pwd=password.encode())
                    elapsed_time = time.time() - start_time
                    print(f"Password found: {password}")
                    print(f"Time taken to find password: {elapsed_time:.2f} seconds")
                    return password
                except (RuntimeError, zipfile.BadZipFile):
                    continue
            print("No valid password found.")
            return None

    def list_files(self, zip_file, password):
        files_dir = os.path.join(os.getcwd(), "Files")
        os.makedirs(files_dir, exist_ok=True)
        with zipfile.ZipFile(zip_file) as zf:
            zf.extractall(path=files_dir, pwd=password.encode())
            files = zf.namelist()
            print("Files in the zip file:")
            for file in files:
                print(file)
        return files, files_dir

    def calculate_checksum(self, file_data):
        sha256_hash = hashlib.sha256()
        sha256_hash.update(file_data)
        return sha256_hash.hexdigest()

    def query_virustotal(self, file_hash, api_key):
        url = f"https://www.virustotal.com/api/v3/files/{file_hash}"
        headers = {
            "x-apikey": api_key
        }
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            json_response = response.json()
            attributes = json_response.get("data", {}).get("attributes", {})
            last_analysis_stats = attributes.get("last_analysis_stats", {})
            positives = last_analysis_stats.get("malicious", 0)
            total = last_analysis_stats.get("total", 0)
            return f"Detection rate: {positives}/{total}"
        else:
            print(f"VirusTotal query failed with status code: {response.status_code}")
            return "VirusTotal query failed"

    def search_keywords(self, file_data, keywords):
        content = file_data.decode(errors='ignore')
        occurrences = {keyword: 0 for keyword in keywords}
        unique_emails = set()
        for keyword in keywords:
            occurrences[keyword] += content.lower().count(keyword.lower())
        emails = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', content)
        unique_emails.update(emails)
        return occurrences, list(unique_emails)

    def generate_report(self, files_data, keywords):
        occurrences = {keyword: 0 for keyword in keywords}
        unique_emails = set()

        for file_name, file_data in files_data.items():
            if file_name.lower().endswith(('.txt', '.pdf')):
                file_occurrences, file_emails = self.search_keywords(file_data, keywords)
                for keyword in keywords:
                    occurrences[keyword] += file_occurrences[keyword]
                unique_emails.update(file_emails)

        report = f"Keyword occurrences: {occurrences}\n"
        report += f"Unique email addresses: {unique_emails}\n"

        # writing a report
        reports_dir = os.path.join(os.getcwd(), "Reports")
        os.makedirs(reports_dir, exist_ok=True)
        report_file = os.path.join(reports_dir, "report.txt")
        with open(report_file, 'w') as f:
            f.write(report)

        # sha256 generate
        with open(report_file, 'rb') as f:
            report_checksum = self.calculate_checksum(f.read())

        hash_file = os.path.join(reports_dir, "hash.txt")
        with open(hash_file, 'w') as f:
            f.write(report_checksum)

        return report_file, report_checksum

    def pack_files_to_zip(self, zip_file, files_data, report_file, password):
        with zipfile.ZipFile(zip_file, 'w') as zf:
            for file_name, file_data in files_data.items():
                zf.writestr(file_name, file_data)
            zf.write(report_file)
            zf.write("Reports/hash.txt")
            zf.setpassword(password.encode())


class Gui(TkinterDnD.Tk):
    def __init__(self):
        super().__init__()
        self.functional = Functional()
        self.initialize_gui()

    def initialize_gui(self):
        self.title("Hash Checker")
        self.geometry("680x1024")
        self.resizable(width=False, height=False)

        # background
        self.background_image = customtkinter.CTkImage(Image.open("back.jpg"), size=(680, 1024))
        self.background_image_label = customtkinter.CTkLabel(master=self, image=self.background_image, text="")
        self.background_image_label.place(x=0, y=0, relwidth=1, relheight=1)

        # Console frame
        self.console_frame = customtkinter.CTkFrame(
            master=self, width=680, height=410, corner_radius=22,
            border_color="#b376d0", bg_color="transparent",
            fg_color="#222222", border_width=4,
            background_corner_colors=("#8d748a", "#9586a7", "#e4c6ac", "#e5ba90")
        )
        self.console_frame.pack(side="bottom")

        # manual frame
        self.manual_frame = customtkinter.CTkFrame(
            master=self, width=220, height=410, corner_radius=22, bg_color="transparent",
            fg_color="white", border_color="#9989ab",
            border_width=4, background_corner_colors=("#8b80a2", "#69576f", "#b7a4b8", "#b79cab")
        )
        self.manual_frame.pack(pady=80)
        self.manual_frame.place(x=440, y=120)

        # file path entry
        self.file_path_entry = customtkinter.CTkEntry(
            master=self, placeholder_text="Input a path...", width=390, height=40, corner_radius=22,
            bg_color="transparent"
        )
        self.file_path_entry.place(x=20, y=420)

        # accept button
        self.accept_button = customtkinter.CTkButton(
            master=self, text="Submit", corner_radius=32, fg_color="#2ddb27",
            bg_color="transparent", border_color="#9989ab", border_width=2,
            command=self.process_file
        )
        self.accept_button.place(x=20, y=470)

        # browse file frame
        self.setup_browse_file_frame()

    def setup_browse_file_frame(self):
        self.browse_file_frame = customtkinter.CTkFrame(
            master=self, width=220, height=220, corner_radius=22,
            bg_color="transparent", fg_color="white"
        )
        self.browse_file_frame.place(x=40, y=120)

        self.browse_file_frame_label = customtkinter.CTkLabel(
            master=self.browse_file_frame, text="Drag file here", width=320,
            height=220, fg_color="white", corner_radius=32
        )
        self.browse_file_frame_label.pack(pady=20, padx=20)

        # register the frame as a drop target
        self.browse_file_frame.drop_target_register(DND_FILES)
        self.browse_file_frame.dnd_bind('<<Drop>>', self.drop)

    def drop(self, event):
        file_path = event.data
        self.browse_file_frame_label.configure(text=f"Dropped file:\n{file_path}")
        self.file_path_entry.delete(0, tk.END)
        self.file_path_entry.insert(0, file_path)

    def process_file(self):
        zip_file = self.file_path_entry.get()
        password_file = "10k-most-common.txt"
        keywords = ["PESEL", "password", "email"]

        passwords = self.functional.read_passwords(password_file)

        # retrieve password
        password = self.functional.retrieve_password(zip_file, passwords)
        if not password:
            print("Exiting due to inability to decrypt the zip file.")
            return

        # list files
        files_in_zip, files_dir = self.functional.list_files(zip_file, password)

        # read file for checksum
        files_data = {}
        for file in files_in_zip:
            file_path = os.path.join(files_dir, file)
            with open(file_path, 'rb') as f:
                files_data[file] = f.read()

        # calculate checksum each
        checksums = {file: self.functional.calculate_checksum(data) for file, data in files_data.items()}

        # query for VirusTotal
        api_key = "ec069afebce3974e9814f21b068a58cbade31d720be74657668a0cfc7e658eb3"
        virus_total_results = {file: self.functional.query_virustotal(checksum, api_key) for file, checksum in checksums.items()}

        # create a report
        report_file, report_checksum = self.functional.generate_report(files_data, keywords)
        print(f"Report generated: {report_file}")
        print(f"Report checksum: {report_checksum}")

        #pack all to zip
        self.functional.pack_files_to_zip(zip_file, files_data, report_file, "P4$$w0rd!")
        print(f"Zip file '{zip_file}' packed with report and hash.")


if __name__ == "__main__":
    app = Gui()
    app.mainloop()
