import csv
import math
from matplotlib import pyplot as plt

def load_Data(filename):
    dataset = []
    with open(filename, 'r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            dataset.append(row)
    return dataset

def convert_to_num(dataset):
    for row in dataset:
        for col in range(len(row)-1):
            row[col] = float(row[col].strip())


def euclidean_distance(x1, x2):
    distance = 0.0
    for i in range(len(x1)-1):
        distance += (x1[i] - x2[i])**2
    return math.sqrt(distance)


def get_neighbors(train, test_instance, k):
    distances = []
    for train_instance in train:
        dist = euclidean_distance(test_instance, train_instance)
        distances.append((train_instance, dist))
    distances.sort(key=lambda x: x[1])
    neighbors = []
    for i in range(k):
        neighbors.append(distances[i][0])
    return neighbors


def predict_classification(train, test_instance, k):
    neighbors = get_neighbors(train, test_instance, k)
    output_values = [row[-1] for row in neighbors]
    prediction = max(set(output_values), key=output_values.count)
    return prediction

def evaluate_algorithm(train, test, k):
    correct = 0
    for test_instance in test:
        prediction = predict_classification(train, test_instance, k)
        print('Prediction:', prediction, 'Current :', test_instance[-1])
        if prediction == test_instance[-1]:
            correct += 1
    accuracy = correct / float(len(test)) * 100.0
    return accuracy



#  -----Console---


trainData = load_Data("iris.data")
rawDataSet = load_Data("iris.test.data")

convert_to_num(trainData)
convert_to_num(rawDataSet)

k_values = list(range(1, 100))
accuracies = []
for k in k_values:
    accuracy = evaluate_algorithm(trainData, rawDataSet, k)
    accuracies.append(accuracy)

plt.bar(k_values, accuracies)
plt.title('Accuracy vs the value of k')
plt.xlabel('k')
plt.ylabel('Accuracy (%)')
plt.show()